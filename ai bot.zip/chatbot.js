let intents = [];

async function loadIntents() {
  const res = await fetch("intents.json");
  const data = await res.json();
  intents = data.intents;
}

function normalize(text) {
  return text.toLowerCase().replace(/[^\w\s]/g, "").trim().replace(/\s+/g, " ");
}

function similarity(a, b) {
  // simple token-overlap (Jaccard) score, good enough for short phrases
  const tokensA = new Set(a.split(" "));
  const tokensB = new Set(b.split(" "));
  const intersection = [...tokensA].filter(t => tokensB.has(t)).length;
  const union = new Set([...tokensA, ...tokensB]).size;
  return union === 0 ? 0 : intersection / union;
}

function classify(text) {
  const normalized = normalize(text);
  let bestIntent = null;
  let bestScore = 0;

  for (const intent of intents) {
    if (intent.tag === "fallback") continue;
    for (const pattern of intent.patterns) {
      const score = similarity(normalized, normalize(pattern));
      if (score > bestScore) {
        bestScore = score;
        bestIntent = intent;
      }
    }
  }

  if (!bestIntent || bestScore < 0.3) {
    return intents.find(i => i.tag === "fallback");
  }
  return bestIntent;
}

function getResponse(text) {
  const intent = classify(text);
  const responses = intent.responses;
  return responses[Math.floor(Math.random() * responses.length)];
}

function appendMessage(text, sender) {
  const chat = document.getElementById("chat");
  const div = document.createElement("div");
  div.className = "msg " + sender;
  div.textContent = text;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

function handleSend() {
  const input = document.getElementById("userInput");
  const text = input.value.trim();
  if (!text) return;

  appendMessage(text, "user");
  const reply = getResponse(text);
  appendMessage(reply, "bot");
  input.value = "";
}

document.getElementById("sendBtn").addEventListener("click", handleSend);
document.getElementById("userInput").addEventListener("keypress", e => {
  if (e.key === "Enter") handleSend();
});

loadIntents();
