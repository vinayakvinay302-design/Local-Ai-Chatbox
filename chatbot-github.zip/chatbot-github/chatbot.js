let intents = [];

const statusEl = document.getElementById("status");
const inputEl = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");

async function loadIntents() {
  try {
    const res = await fetch("intents.json");
    if (!res.ok) {
      throw new Error(`HTTP ${res.status} while fetching intents.json`);
    }
    const data = await res.json();
    intents = data.intents;

    statusEl.textContent = `Loaded ${intents.length} intents. Ready to chat!`;
    statusEl.className = "ok";
    inputEl.disabled = false;
    sendBtn.disabled = false;
    inputEl.focus();
  } catch (err) {
    statusEl.textContent =
      "Failed to load intents.json. If you opened this file directly " +
      "(file://), run a local server instead, e.g. `python -m http.server` " +
      "then open http://localhost:8000. Error: " + err.message;
    statusEl.className = "error";
    console.error(err);
  }
}

function normalize(text) {
  return text.toLowerCase().replace(/[^\w\s]/g, "").trim().replace(/\s+/g, " ");
}

function similarity(a, b) {
  const tokensA = new Set(a.split(" ").filter(Boolean));
  const tokensB = new Set(b.split(" ").filter(Boolean));
  const intersection = [...tokensA].filter(t => tokensB.has(t)).length;
  const union = new Set([...tokensA, ...tokensB]).size;
  return union === 0 ? 0 : intersection / union;
}

function classify(text) {
  const normalized = normalize(text);
  let bestIntent = null;
  let bestScore = 0;

  for (const intent of intents) {
    if (intent.tag === "fallback") continue;
    for (const pattern of intent.patterns) {
      const score = similarity(normalized, normalize(pattern));
      if (score > bestScore) {
        bestScore = score;
        bestIntent = intent;
      }
    }
  }

  if (!bestIntent || bestScore < 0.3) {
    return intents.find(i => i.tag === "fallback");
  }
  return bestIntent;
}

function getResponse(text) {
  const intent = classify(text);
  const responses = intent.responses;
  return responses[Math.floor(Math.random() * responses.length)];
}

function appendMessage(text, sender) {
  const chat = document.getElementById("chat");
  const div = document.createElement("div");
  div.className = "msg " + sender;
  div.textContent = text;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

function handleSend() {
  const text = inputEl.value.trim();
  if (!text) return;

  appendMessage(text, "user");
  const reply = getResponse(text);
  appendMessage(reply, "bot");
  inputEl.value = "";
  inputEl.focus();
}

sendBtn.addEventListener("click", handleSend);
inputEl.addEventListener("keypress", e => {
  if (e.key === "Enter") handleSend();
});

loadIntents();
